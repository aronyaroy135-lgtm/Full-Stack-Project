const bcrypt = require('bcryptjs');
const { db, slugify } = require('./db');

if (db.prepare('SELECT COUNT(*) n FROM users').get().n > 0 && !process.argv.includes('--force')) {
  console.log('Database already has data. Run with --force to add the demo content again.');
  process.exit(0);
}

const hash = (p) => bcrypt.hashSync(p, 10);
const addUser = db.prepare('INSERT OR IGNORE INTO users (username,email,password_hash,role,bio) VALUES (?,?,?,?,?)');
addUser.run('admin', 'admin@inkwell.dev', hash('admin12345'), 'admin', 'Keeps the ink flowing and the comments kind.');
addUser.run('maya', 'maya@inkwell.dev', hash('password123'), 'user', 'Designer writing about slow software and calm interfaces.');
addUser.run('arjun', 'arjun@inkwell.dev', hash('password123'), 'user', 'Backend engineer. Collects mechanical keyboards and bad puns.');
addUser.run('sofia', 'sofia@inkwell.dev', hash('password123'), 'user', 'Traveller, cook, and occasional poet.');

const cats = [
  ['Technology', '#4f46e5'], ['Design', '#db2777'], ['Travel', '#0891b2'],
  ['Food', '#ea580c'], ['Life', '#059669'], ['Writing', '#7c3aed'],
];
const addCat = db.prepare('INSERT OR IGNORE INTO categories (name,slug,color) VALUES (?,?,?)');
cats.forEach(([n, c]) => addCat.run(n, slugify(n), c));

const uid = (n) => db.prepare('SELECT id FROM users WHERE username = ?').get(n).id;
const cid = (n) => db.prepare('SELECT id FROM categories WHERE name = ?').get(n).id;

const posts = [
  ['maya', 'Design', 'The case for slow interfaces', ['ux', 'design', 'craft'], 0,
`Speed is the metric everyone chases, but **some of the best moments in software are deliberately unhurried**.

## Motion that explains

A drawer that slides open tells you where it came from and where it will go. A toast that fades says *"that worked"* without shouting. The point of animation is not decoration; it is **orientation**.

> If a transition does not answer the question "what just changed?", delete it.

## A small checklist

- Keep entrances under 300ms
- Animate the thing the person touched
- Respect \`prefers-reduced-motion\`
- Never block input while something moves

Slow does not mean sluggish. It means *intentional*.`],
  ['arjun', 'Technology', 'SQLite is enough for more projects than you think', ['sqlite', 'backend', 'databases'], 1,
`Before reaching for a managed Postgres cluster, ask a simple question: **how many writes per second do you actually have?**

## Why it works

SQLite runs in-process, so there is no network hop. With WAL mode, readers never block the writer, and a single modest server can handle thousands of requests a second.

## When to move on

1. You need many app servers writing at once
2. You need row-level replication
3. Your dataset outgrows one disk

Until then, one file, one backup, zero ops. \`cp inkwell.db backup.db\` is a disaster-recovery plan.`],
  ['sofia', 'Travel', 'Three days in Kyoto without a checklist', ['travel', 'japan', 'slow-travel'], 2,
`I arrived with a spreadsheet of forty temples. I left having visited six, and remembered all of them.

## Day one: wander

Walk the Philosopher's Path early, before the tour buses. Stop wherever the light looks good.

## Day two: eat

Skip the famous queue. Follow the smell of grilled mochi down any side street and sit where the locals sit.

## Day three: do nothing

Find a tea house with a garden view. Order slowly. Watch the moss.

> The best itinerary is the one you are willing to abandon.`],
  ['maya', 'Writing', 'How to write a first draft you can actually fix', ['writing', 'process', 'habits'], 3,
`The first draft has one job: **exist**.

## Lower the bar on purpose

Set a timer for twenty-five minutes. Write badly. Do not edit, do not look up facts, do not reread.

## Then switch hats

Editing is a different skill from drafting. Mixing them is why most people stall on page one.

- Draft in the morning, edit after lunch
- Leave notes in [brackets] and keep moving
- Read the piece out loud before you publish`],
  ['sofia', 'Food', 'A weeknight dal that tastes like a weekend', ['cooking', 'vegetarian', 'recipes'], 4,
`Good dal is about **timing the tadka**, not about long simmering.

## Ingredients

- 1 cup red lentils, rinsed
- 1 tsp turmeric
- 2 tbsp ghee
- 1 tsp cumin seeds, 3 cloves garlic, 2 dried chillies

## Method

1. Simmer lentils with turmeric and salt for 20 minutes until soft
2. Heat ghee, pop the cumin, then add garlic and chillies
3. Pour the sizzling tadka over the dal and cover for one minute

Finish with lemon and fresh coriander.`],
  ['arjun', 'Life', 'What a year of daily journaling taught me', ['habits', 'journaling', 'life'], 5,
`I started journaling to remember things. I kept going because it quietly changed **how I notice things**.

## What I noticed

- Worry shrinks when it has to become a sentence
- Small wins pile up faster than you expect
- Bad days read differently a month later

You do not need a leather notebook. A text file and five minutes is plenty.`],
  ['maya', 'Technology', 'Dark mode is not just inverted colors', ['css', 'design', 'frontend'], 6,
`Flipping white to black is the fastest way to ship a **bad** dark theme.

## Surfaces need depth

In light mode we use shadows. In dark mode, lighter surfaces feel closer. Build a ladder of three or four elevations.

## Check your contrast

Pure white text on pure black vibrates. Soften both ends and test with real content.`],
  ['sofia', 'Design', 'Notes on picking a typeface for long reading', ['typography', 'design', 'reading'], 7,
`Reading for twenty minutes is a different job from scanning for two seconds.

## What to look for

- Open apertures that stay legible when small
- Generous line height, around **1.65** for serif body text
- Lines under about seventy characters

Pick one family you trust and let the layout do the rest.`],
];

const addPost = db.prepare(`INSERT INTO posts (author_id,category_id,title,slug,excerpt,content,cover,status,views,created_at,updated_at,published_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
posts.forEach(([author, cat, title, tags, cover, content], i) => {
  const when = new Date(Date.now() - (posts.length - i) * 86400000 * 1.4).toISOString();
  const excerpt = content.replace(/[#*_`>\[\]()!-]/g, '').replace(/\s+/g, ' ').trim().slice(0, 150) + '…';
  const info = addPost.run(uid(author), cid(cat), title, slugify(title), excerpt, content, cover, 'published', 40 + i * 37, when, when, when);
  tags.forEach((t) => {
    db.prepare('INSERT OR IGNORE INTO tags (name,slug) VALUES (?,?)').run(t, slugify(t));
    db.prepare('INSERT OR IGNORE INTO post_tags (post_id,tag_id) VALUES (?,?)').run(info.lastInsertRowid, db.prepare('SELECT id FROM tags WHERE slug=?').get(slugify(t)).id);
  });
});

const first = db.prepare('SELECT id FROM posts ORDER BY id LIMIT 3').all();
const addComment = db.prepare('INSERT INTO comments (post_id,user_id,body) VALUES (?,?,?)');
addComment.run(first[0].id, uid('arjun'), 'The checklist at the end is going straight into our design review template.');
addComment.run(first[0].id, uid('sofia'), 'Orientation is exactly the right word for it.');
addComment.run(first[1].id, uid('maya'), 'Using SQLite for my side project since this post. No regrets.');
addPost.run(uid('arjun'), cid('Technology'), 'Draft: notes on rate limiting', 'draft-notes-on-rate-limiting', 'Work in progress.', 'Token bucket, sliding window, and why both are fine for a small API.', 1, 'draft', 0, new Date().toISOString(), new Date().toISOString(), null);

console.log('Seeded. Sign in as admin / admin12345  or  maya / password123');
