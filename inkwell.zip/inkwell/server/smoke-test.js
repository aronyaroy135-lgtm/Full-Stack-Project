// End-to-end API check. Uses a throwaway database so your real data is untouched.
const os = require('os');
const path = require('path');
const fs = require('fs');
const assert = require('assert');

const tmp = path.join(os.tmpdir(), `inkwell-test-${Date.now()}.db`);
process.env.DB_FILE = tmp;
process.env.PORT = '0';

const bcrypt = require('bcryptjs');
const { db } = require('./db');
const app = require('./index');

(async () => {
  db.prepare(`INSERT INTO users (username,email,password_hash,role) VALUES ('boss','boss@x.io',?,'admin')`).run(bcrypt.hashSync('bosspass123', 4));
  db.prepare(`INSERT INTO categories (name,slug) VALUES ('Tech','tech')`).run();

  const server = app.listen(0);
  const base = `http://127.0.0.1:${server.address().port}/api`;
  const call = async (method, url, body, token) => {
    const r = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    return { status: r.status, data: await r.json() };
  };
  let n = 0;
  const ok = (name, cond) => { assert.ok(cond, 'FAILED: ' + name); console.log('  ✓', name); n++; };

  let r = await call('POST', '/auth/register', { username: 'ada', email: 'ada@x.io', password: 'short' });
  ok('rejects short password', r.status === 400);
  r = await call('POST', '/auth/register', { username: 'ada', email: 'ada@x.io', password: 'longenough1' });
  ok('registers a user', r.status === 201 && r.data.token);
  const ada = r.data.token;
  r = await call('POST', '/auth/register', { username: 'ada', email: 'other@x.io', password: 'longenough1' });
  ok('blocks duplicate username', r.status === 409);
  r = await call('POST', '/auth/login', { identifier: 'ada@x.io', password: 'longenough1' });
  ok('logs in with email', r.status === 200);
  r = await call('POST', '/auth/login', { identifier: 'ada', password: 'wrong' });
  ok('rejects bad password', r.status === 401);

  r = await call('POST', '/posts', { title: 'Hi', content: 'x' });
  ok('create requires sign-in', r.status === 401);
  r = await call('POST', '/posts', { title: 'Hello Inkwell', content: 'A long enough body for the first article.', status: 'published', tags: 'node, sqlite', category_id: 1 }, ada);
  ok('creates a published post', r.status === 201 && r.data.slug === 'hello-inkwell' && r.data.tags.length === 2);
  const postId = r.data.id;
  r = await call('POST', '/posts', { title: 'Hello Inkwell', content: 'Same title again, different body here.', status: 'draft' }, ada);
  ok('makes slugs unique', r.data.slug === 'hello-inkwell-2');
  const draftId = r.data.id;

  r = await call('GET', '/posts');
  ok('lists only published posts', r.data.total === 1);
  r = await call('GET', '/posts?q=sqlite');
  ok('search finds nothing in body text for tag-only word', r.data.total === 0);
  r = await call('GET', '/posts?q=first+article');
  ok('search matches body text', r.data.total === 1);
  r = await call('GET', '/posts?tag=sqlite');
  ok('filters by tag', r.data.total === 1);
  r = await call('GET', '/posts?category=tech');
  ok('filters by category', r.data.total === 1);

  r = await call('GET', '/posts/hello-inkwell-2');
  ok('hides drafts from the public', r.status === 404);
  r = await call('GET', '/posts/hello-inkwell-2', null, ada);
  ok('author can open own draft', r.status === 200);

  r = await call('PUT', `/posts/${postId}`, { title: 'Hello Inkwell, updated', content: 'Edited body that is long enough to save.', status: 'published', tags: ['node'] }, ada);
  ok('updates a post', r.status === 200 && r.data.tags.length === 1);

  r = await call('POST', '/auth/register', { username: 'bob', email: 'bob@x.io', password: 'longenough1' });
  const bob = r.data.token;
  r = await call('PUT', `/posts/${postId}`, { title: 'Hijack attempt', content: 'Trying to edit someone else post.' }, bob);
  ok("blocks editing someone else's post", r.status === 403);

  r = await call('POST', `/posts/${postId}/like`, null, bob);
  ok('likes a post', r.data.liked === true && r.data.likes === 1);
  r = await call('POST', `/posts/${postId}/like`, null, bob);
  ok('unlikes a post', r.data.liked === false && r.data.likes === 0);

  r = await call('POST', `/posts/${postId}/comments`, { body: 'Nice read!' }, bob);
  ok('adds a comment', r.status === 201);
  const commentId = r.data.id;
  r = await call('GET', `/posts/${postId}/comments`);
  ok('lists comments', r.data.length === 1);

  r = await call('GET', '/admin/stats', null, bob);
  ok('admin routes block normal users', r.status === 403);
  r = await call('POST', '/auth/login', { identifier: 'boss', password: 'bosspass123' });
  const boss = r.data.token;
  r = await call('GET', '/admin/stats', null, boss);
  ok('admin sees stats', r.status === 200 && r.data.users === 3);
  r = await call('PATCH', `/admin/comments/${commentId}`, { status: 'hidden' }, boss);
  r = await call('GET', `/posts/${postId}/comments`);
  ok('hidden comments disappear', r.data.length === 0);
  r = await call('PATCH', `/admin/posts/${postId}`, { status: 'hidden' }, boss);
  r = await call('GET', '/posts');
  ok('moderated posts leave the feed', r.data.total === 0);
  r = await call('GET', '/admin/users', null, boss);
  const bobRow = r.data.find((u) => u.username === 'bob');
  await call('PATCH', `/admin/users/${bobRow.id}`, { status: 'banned' }, boss);
  r = await call('POST', '/auth/login', { identifier: 'bob', password: 'longenough1' });
  ok('banned users cannot sign in', r.status === 403);
  r = await call('DELETE', `/posts/${draftId}`, null, ada);
  ok('author deletes own post', r.status === 200);

  console.log(`\nAll ${n} checks passed.`);
  server.close();
  db.close();
  for (const s of ['', '-wal', '-shm']) fs.rmSync(tmp + s, { force: true });
  process.exit(0);
})().catch((e) => { console.error(e.message); process.exit(1); });
