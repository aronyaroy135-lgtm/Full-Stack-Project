const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { db, slugify } = require('./db');

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me';
const app = express();

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:'],
        scriptSrc: ["'self'"],
        connectSrc: ["'self'"],
      },
    },
  })
);
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false });

// ---------- helpers ----------
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const clean = (v, max) => String(v ?? '').trim().slice(0, max);

const publicUser = (u) => u && { id: u.id, username: u.username, email: u.email, role: u.role, status: u.status, bio: u.bio, created_at: u.created_at };
const sign = (u) => jwt.sign({ id: u.id }, JWT_SECRET, { expiresIn: '7d' });

function optionalAuth(req, _res, next) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) {
    try {
      const { id } = jwt.verify(h.slice(7), JWT_SECRET);
      const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
      if (u && u.status === 'active') req.user = u;
    } catch { /* ignore invalid token */ }
  }
  next();
}
function requireAuth(req, res, next) {
  if (!req.user) return bad(res, 'Please sign in to continue.', 401);
  next();
}
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') return bad(res, 'Admins only.', 403);
  next();
}
app.use('/api', optionalAuth);

const POST_SELECT = `
  SELECT p.id, p.title, p.slug, p.excerpt, p.cover, p.status, p.views, p.created_at, p.updated_at, p.published_at,
         u.username AS author, u.id AS author_id,
         c.name AS category, c.slug AS category_slug, c.color AS category_color,
         (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS likes,
         (SELECT COUNT(*) FROM comments m WHERE m.post_id = p.id AND m.status = 'visible') AS comment_count,
         (SELECT group_concat(t.name, ',') FROM post_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.post_id = p.id) AS tag_list
  FROM posts p
  JOIN users u ON u.id = p.author_id
  LEFT JOIN categories c ON c.id = p.category_id`;

const shapePost = (r) => r && { ...r, tags: r.tag_list ? r.tag_list.split(',') : [], tag_list: undefined };

function makeExcerpt(text) {
  const t = String(text)
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/^\s*(#{1,6}|>|[-*]|\d+\.)\s+/gm, '')
    .replace(/[*_`]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (t.length <= 160) return t;
  return t.slice(0, 160).replace(/\s+\S*$/, '') + '…';
}

const readTime = (text) => Math.max(1, Math.round(String(text).split(/\s+/).length / 210));

function uniqueSlug(title, ignoreId = 0) {
  const base = slugify(title);
  let slug = base, i = 2;
  while (db.prepare('SELECT 1 FROM posts WHERE slug = ? AND id != ?').get(slug, ignoreId)) slug = `${base}-${i++}`;
  return slug;
}

function setTags(postId, tags) {
  db.prepare('DELETE FROM post_tags WHERE post_id = ?').run(postId);
  const list = [...new Set((Array.isArray(tags) ? tags : String(tags || '').split(',')).map((t) => clean(t, 24).toLowerCase()).filter(Boolean))].slice(0, 6);
  for (const name of list) {
    const slug = slugify(name);
    db.prepare('INSERT OR IGNORE INTO tags (name, slug) VALUES (?, ?)').run(name, slug);
    const tag = db.prepare('SELECT id FROM tags WHERE slug = ?').get(slug);
    db.prepare('INSERT OR IGNORE INTO post_tags (post_id, tag_id) VALUES (?, ?)').run(postId, tag.id);
  }
}

// ---------- auth ----------
app.post('/api/auth/register', authLimiter, wrap((req, res) => {
  const username = clean(req.body.username, 24);
  const email = clean(req.body.email, 120).toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return bad(res, 'Username must be 3–24 letters, numbers or underscores.');
  if (!/^\S+@\S+\.\S+$/.test(email)) return bad(res, 'Enter a valid email address.');
  if (password.length < 8) return bad(res, 'Password must be at least 8 characters.');
  if (db.prepare('SELECT 1 FROM users WHERE username = ? OR email = ?').get(username, email)) return bad(res, 'That username or email is already taken.', 409);
  const info = db.prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)').run(username, email, bcrypt.hashSync(password, 10));
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ token: sign(user), user: publicUser(user) });
}));

app.post('/api/auth/login', authLimiter, wrap((req, res) => {
  const id = clean(req.body.identifier, 120);
  const user = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(id, id);
  if (!user || !bcrypt.compareSync(String(req.body.password || ''), user.password_hash)) return bad(res, 'Wrong username or password.', 401);
  if (user.status === 'banned') return bad(res, 'This account has been suspended.', 403);
  res.json({ token: sign(user), user: publicUser(user) });
}));

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

app.put('/api/auth/me', requireAuth, wrap((req, res) => {
  const bio = clean(req.body.bio, 280);
  db.prepare('UPDATE users SET bio = ? WHERE id = ?').run(bio, req.user.id);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
}));

// ---------- taxonomy ----------
app.get('/api/categories', (_req, res) => {
  res.json(db.prepare(`SELECT c.*, (SELECT COUNT(*) FROM posts p WHERE p.category_id = c.id AND p.status='published') AS count FROM categories c ORDER BY c.name`).all());
});
app.get('/api/tags', (_req, res) => {
  res.json(db.prepare(`SELECT t.name, t.slug, COUNT(p.id) AS count FROM tags t JOIN post_tags pt ON pt.tag_id = t.id JOIN posts p ON p.id = pt.post_id AND p.status='published' GROUP BY t.id ORDER BY count DESC, t.name LIMIT 24`).all());
});

// ---------- posts ----------
app.get('/api/posts', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(24, parseInt(req.query.limit) || 9);
  const where = [`p.status = 'published'`];
  const args = [];
  if (req.query.q) {
    const like = `%${clean(req.query.q, 80).replace(/[%_]/g, '\\$&')}%`;
    where.push(`(p.title LIKE ? ESCAPE '\\' OR p.excerpt LIKE ? ESCAPE '\\' OR p.content LIKE ? ESCAPE '\\' OR u.username LIKE ? ESCAPE '\\')`);
    args.push(like, like, like, like);
  }
  if (req.query.category) { where.push('c.slug = ?'); args.push(String(req.query.category)); }
  if (req.query.tag) { where.push('EXISTS (SELECT 1 FROM post_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.post_id = p.id AND t.slug = ?)'); args.push(String(req.query.tag)); }
  if (req.query.author) { where.push('u.username = ?'); args.push(String(req.query.author)); }
  const order = { popular: 'p.views DESC', liked: 'likes DESC', new: 'p.published_at DESC' }[req.query.sort] || 'p.published_at DESC';
  const sqlWhere = ' WHERE ' + where.join(' AND ');
  const total = db.prepare(`SELECT COUNT(*) n FROM posts p JOIN users u ON u.id=p.author_id LEFT JOIN categories c ON c.id=p.category_id ${sqlWhere}`).get(...args).n;
  const rows = db.prepare(`${POST_SELECT} ${sqlWhere} ORDER BY ${order} LIMIT ? OFFSET ?`).all(...args, limit, (page - 1) * limit);
  res.json({ posts: rows.map(shapePost), total, page, pages: Math.max(1, Math.ceil(total / limit)) });
});

app.get('/api/my/posts', requireAuth, (req, res) => {
  res.json(db.prepare(`${POST_SELECT} WHERE p.author_id = ? ORDER BY p.updated_at DESC`).all(req.user.id).map(shapePost));
});

app.get('/api/posts/:slug', (req, res) => {
  const row = db.prepare(`${POST_SELECT} WHERE p.slug = ?`).get(req.params.slug);
  if (!row) return bad(res, 'That article does not exist.', 404);
  const mine = req.user && (req.user.id === row.author_id || req.user.role === 'admin');
  if (row.status !== 'published' && !mine) return bad(res, 'That article does not exist.', 404);
  if (row.status === 'published' && !(req.user && req.user.id === row.author_id)) db.prepare('UPDATE posts SET views = views + 1 WHERE id = ?').run(row.id);
  const { content } = db.prepare('SELECT content FROM posts WHERE id = ?').get(row.id);
  const liked = req.user ? !!db.prepare('SELECT 1 FROM likes WHERE user_id = ? AND post_id = ?').get(req.user.id, row.id) : false;
  res.json({ ...shapePost(row), content, liked, read_minutes: readTime(content) });
});

function readPostBody(body) {
  const title = clean(body.title, 140);
  const content = String(body.content || '').slice(0, 60000);
  if (title.length < 3) return { error: 'Add a title of at least 3 characters.' };
  if (content.trim().length < 20) return { error: 'Write at least a few sentences before saving.' };
  const status = body.status === 'published' ? 'published' : 'draft';
  const excerpt = clean(body.excerpt, 240) || makeExcerpt(content);
  const category = body.category_id ? db.prepare('SELECT id FROM categories WHERE id = ?').get(Number(body.category_id)) : null;
  return { title, content, status, excerpt, category_id: category ? category.id : null, cover: Math.abs(parseInt(body.cover) || 0) % 8 };
}

app.post('/api/posts', requireAuth, wrap((req, res) => {
  const b = readPostBody(req.body);
  if (b.error) return bad(res, b.error);
  const info = db.prepare(`INSERT INTO posts (author_id, category_id, title, slug, excerpt, content, cover, status, published_at) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(req.user.id, b.category_id, b.title, uniqueSlug(b.title), b.excerpt, b.content, b.cover, b.status, b.status === 'published' ? new Date().toISOString() : null);
  setTags(info.lastInsertRowid, req.body.tags);
  res.status(201).json(shapePost(db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(info.lastInsertRowid)));
}));

app.put('/api/posts/:id', requireAuth, wrap((req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(Number(req.params.id));
  if (!post) return bad(res, 'Article not found.', 404);
  if (post.author_id !== req.user.id && req.user.role !== 'admin') return bad(res, 'You can only edit your own articles.', 403);
  const b = readPostBody(req.body);
  if (b.error) return bad(res, b.error);
  const status = post.status === 'hidden' && req.user.role !== 'admin' ? 'hidden' : b.status;
  const publishedAt = status === 'published' ? post.published_at || new Date().toISOString() : post.published_at;
  db.prepare(`UPDATE posts SET title=?, slug=?, excerpt=?, content=?, category_id=?, cover=?, status=?, published_at=?, updated_at=datetime('now') WHERE id=?`)
    .run(b.title, b.title !== post.title ? uniqueSlug(b.title, post.id) : post.slug, b.excerpt, b.content, b.category_id, b.cover, status, publishedAt, post.id);
  setTags(post.id, req.body.tags);
  res.json(shapePost(db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(post.id)));
}));

app.delete('/api/posts/:id', requireAuth, wrap((req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(Number(req.params.id));
  if (!post) return bad(res, 'Article not found.', 404);
  if (post.author_id !== req.user.id && req.user.role !== 'admin') return bad(res, 'You can only delete your own articles.', 403);
  db.prepare('DELETE FROM posts WHERE id = ?').run(post.id);
  res.json({ ok: true });
}));

app.post('/api/posts/:id/like', requireAuth, wrap((req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare(`SELECT 1 FROM posts WHERE id = ? AND status = 'published'`).get(id)) return bad(res, 'Article not found.', 404);
  const had = db.prepare('SELECT 1 FROM likes WHERE user_id = ? AND post_id = ?').get(req.user.id, id);
  if (had) db.prepare('DELETE FROM likes WHERE user_id = ? AND post_id = ?').run(req.user.id, id);
  else db.prepare('INSERT INTO likes (user_id, post_id) VALUES (?, ?)').run(req.user.id, id);
  res.json({ liked: !had, likes: db.prepare('SELECT COUNT(*) n FROM likes WHERE post_id = ?').get(id).n });
}));

// ---------- comments ----------
app.get('/api/posts/:id/comments', (req, res) => {
  res.json(db.prepare(`SELECT m.id, m.body, m.created_at, m.user_id, u.username FROM comments m JOIN users u ON u.id = m.user_id WHERE m.post_id = ? AND m.status = 'visible' ORDER BY m.created_at ASC, m.id ASC`).all(Number(req.params.id)));
});

app.post('/api/posts/:id/comments', requireAuth, wrap((req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare(`SELECT 1 FROM posts WHERE id = ? AND status = 'published'`).get(id)) return bad(res, 'Article not found.', 404);
  const body = clean(req.body.body, 1000);
  if (body.length < 2) return bad(res, 'Write a comment before posting.');
  const info = db.prepare('INSERT INTO comments (post_id, user_id, body) VALUES (?,?,?)').run(id, req.user.id, body);
  res.status(201).json(db.prepare('SELECT m.id, m.body, m.created_at, m.user_id, u.username FROM comments m JOIN users u ON u.id = m.user_id WHERE m.id = ?').get(info.lastInsertRowid));
}));

app.delete('/api/comments/:id', requireAuth, wrap((req, res) => {
  const c = db.prepare('SELECT * FROM comments WHERE id = ?').get(Number(req.params.id));
  if (!c) return bad(res, 'Comment not found.', 404);
  if (c.user_id !== req.user.id && req.user.role !== 'admin') return bad(res, 'You can only delete your own comments.', 403);
  db.prepare('DELETE FROM comments WHERE id = ?').run(c.id);
  res.json({ ok: true });
}));

// ---------- site numbers ----------
app.get('/api/meta', (_req, res) => {
  const n = (sql) => db.prepare(sql).get().n;
  res.json({
    writers: n(`SELECT COUNT(DISTINCT author_id) n FROM posts WHERE status='published'`),
    articles: n(`SELECT COUNT(*) n FROM posts WHERE status='published'`),
    comments: n(`SELECT COUNT(*) n FROM comments WHERE status='visible'`),
    reads: n(`SELECT COALESCE(SUM(views),0) n FROM posts WHERE status='published'`),
  });
});

// ---------- profiles ----------
app.get('/api/users/:username', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE username = ?').get(req.params.username);
  if (!u || u.status === 'banned') return bad(res, 'Writer not found.', 404);
  const stats = db.prepare(`SELECT COUNT(*) posts, COALESCE(SUM(views),0) views FROM posts WHERE author_id = ? AND status='published'`).get(u.id);
  res.json({ username: u.username, bio: u.bio, created_at: u.created_at, ...stats });
});

// ---------- admin ----------
const admin = express.Router();
admin.use(requireAuth, requireAdmin);

admin.get('/stats', (_req, res) => {
  const n = (sql) => db.prepare(sql).get().n;
  res.json({
    users: n('SELECT COUNT(*) n FROM users'),
    posts: n(`SELECT COUNT(*) n FROM posts WHERE status='published'`),
    drafts: n(`SELECT COUNT(*) n FROM posts WHERE status='draft'`),
    hidden: n(`SELECT COUNT(*) n FROM posts WHERE status='hidden'`),
    comments: n('SELECT COUNT(*) n FROM comments'),
    views: n('SELECT COALESCE(SUM(views),0) n FROM posts'),
    perDay: db.prepare(`SELECT date(published_at) d, COUNT(*) n FROM posts WHERE status='published' AND published_at >= date('now','-13 days') GROUP BY d ORDER BY d`).all(),
  });
});
admin.get('/users', (_req, res) => {
  res.json(db.prepare(`SELECT u.id, u.username, u.email, u.role, u.status, u.created_at, (SELECT COUNT(*) FROM posts p WHERE p.author_id = u.id) AS posts FROM users u ORDER BY u.created_at DESC`).all());
});
admin.patch('/users/:id', wrap((req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return bad(res, 'You cannot change your own role or status.');
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return bad(res, 'User not found.', 404);
  const role = ['user', 'admin'].includes(req.body.role) ? req.body.role : u.role;
  const status = ['active', 'banned'].includes(req.body.status) ? req.body.status : u.status;
  db.prepare('UPDATE users SET role = ?, status = ? WHERE id = ?').run(role, status, id);
  res.json({ ok: true });
}));
admin.get('/posts', (_req, res) => {
  res.json(db.prepare(`${POST_SELECT} ORDER BY p.updated_at DESC LIMIT 200`).all().map(shapePost));
});
admin.patch('/posts/:id', wrap((req, res) => {
  const id = Number(req.params.id);
  const status = req.body.status;
  if (!['published', 'hidden', 'draft'].includes(status)) return bad(res, 'Invalid status.');
  const p = db.prepare('SELECT * FROM posts WHERE id = ?').get(id);
  if (!p) return bad(res, 'Article not found.', 404);
  db.prepare('UPDATE posts SET status = ?, published_at = COALESCE(published_at, CASE WHEN ? = \'published\' THEN datetime(\'now\') END) WHERE id = ?').run(status, status, id);
  res.json({ ok: true });
}));
admin.get('/comments', (_req, res) => {
  res.json(db.prepare(`SELECT m.id, m.body, m.status, m.created_at, u.username, p.title AS post_title, p.slug FROM comments m JOIN users u ON u.id = m.user_id JOIN posts p ON p.id = m.post_id ORDER BY m.created_at DESC LIMIT 200`).all());
});
admin.patch('/comments/:id', wrap((req, res) => {
  const status = req.body.status === 'hidden' ? 'hidden' : 'visible';
  db.prepare('UPDATE comments SET status = ? WHERE id = ?').run(status, Number(req.params.id));
  res.json({ ok: true });
}));
admin.post('/categories', wrap((req, res) => {
  const name = clean(req.body.name, 30);
  if (name.length < 2) return bad(res, 'Category name is too short.');
  const color = /^#[0-9a-f]{6}$/i.test(req.body.color || '') ? req.body.color : '#6d5efc';
  try { db.prepare('INSERT INTO categories (name, slug, color) VALUES (?,?,?)').run(name, slugify(name), color); }
  catch { return bad(res, 'That category already exists.', 409); }
  res.status(201).json({ ok: true });
}));
admin.delete('/categories/:id', (req, res) => {
  db.prepare('DELETE FROM categories WHERE id = ?').run(Number(req.params.id));
  res.json({ ok: true });
});
app.use('/api/admin', admin);

app.use('/api', (_req, res) => bad(res, 'Unknown endpoint.', 404));

// ---------- static frontend ----------
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use((_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on our side. Try again.' });
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Inkwell is running at http://localhost:${PORT}`));
}
module.exports = app;
