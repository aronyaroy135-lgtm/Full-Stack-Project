# Inkwell

A full-stack blog publishing platform. Registered users write, publish and manage articles; readers search, filter, like and comment; admins moderate everything.

**Stack:** Node.js + Express, SQLite (better-sqlite3), JWT auth with bcrypt, and a hand-built single-page frontend (vanilla JS, CSS, canvas) with no build step.

## Run it

```bash
npm install
npm run seed     # optional: demo writers, articles and comments
npm start        # http://localhost:3000
```

Needs Node 18 or newer. `npm run dev` restarts the server when you edit files.

### Demo accounts (after `npm run seed`)

| Role  | Username | Password     |
|-------|----------|--------------|
| Admin | `admin`  | `admin12345` |
| Writer| `maya`   | `password123`|

Change these before putting the site anywhere public.

### Configuration

| Variable     | Default                  | Purpose                                  |
|--------------|--------------------------|------------------------------------------|
| `PORT`       | `3000`                   | HTTP port                                |
| `JWT_SECRET` | dev-only placeholder     | **Set this in production.** Signs logins |
| `DB_FILE`    | `data/inkwell.db`        | SQLite database location                 |

Example: `JWT_SECRET="a-long-random-string" PORT=8080 npm start`

## Features

- **Accounts:** register, sign in, public profile with editable bio, suspended accounts blocked at login.
- **Articles:** create, edit, delete, save drafts, publish. Markdown editor with a live preview, formatting toolbar, word count, autosaved new drafts, and 8 generated cover designs.
- **Organising:** one category per article, up to 6 tags, filter by either.
- **Reading:** search across titles, summaries, body text and writers; sort by newest, most read or most liked; reading-progress bar; read-time estimates; view counts.
- **Community:** likes, comments (add and delete your own).
- **Admin:** site overview with a 14-day chart, hide or restore articles and comments, ban or restore writers, promote admins, manage categories.
- **Design:** light and dark themes, an interactive ink canvas in the hero, animated covers, counters, charts, toasts and dialogs. Everything respects `prefers-reduced-motion` and works on phones.

## Project layout

```
server/
  index.js        Express app and every API route
  db.js           SQLite schema
  seed.js         Demo data
  smoke-test.js   27 end-to-end API checks (npm test)
public/
  index.html      App shell
  css/style.css   Design system and animations
  js/app.js       Router, pages, markdown renderer
  js/ink.js       Hero ink canvas
  js/theme.js     Applies saved theme before first paint
```

## API summary

| Method | Path | Notes |
|--------|------|-------|
| POST | `/api/auth/register`, `/api/auth/login` | Returns `{ token, user }` |
| GET/PUT | `/api/auth/me` | Current user, update bio |
| GET | `/api/posts` | `q`, `category`, `tag`, `author`, `sort`, `page`, `limit` |
| GET | `/api/posts/:slug` | Drafts visible only to the author and admins |
| POST/PUT/DELETE | `/api/posts`, `/api/posts/:id` | Owner or admin |
| POST | `/api/posts/:id/like` | Toggles like |
| GET/POST | `/api/posts/:id/comments` | |
| DELETE | `/api/comments/:id` | Owner or admin |
| GET | `/api/categories`, `/api/tags`, `/api/meta`, `/api/users/:username` | Public |
| GET/PATCH/POST/DELETE | `/api/admin/*` | Admin only: stats, users, posts, comments, categories |

Send the token as `Authorization: Bearer <token>`.

## Security notes

Passwords are hashed with bcrypt. All SQL uses prepared statements. Article Markdown is HTML-escaped before it is rendered, and the server sends a strict Content-Security-Policy (no inline scripts). Sign-in and registration are rate limited.
