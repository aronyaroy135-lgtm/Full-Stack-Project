(() => {
'use strict';

/* ============ Helpers ============ */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
  del: (k) => { try { localStorage.removeItem(k); } catch { /* storage unavailable */ } },
};
const state = { token: store.get('ink_token'), user: null, cats: [] };
let cleanups = [];
const onCleanup = (fn) => cleanups.push(fn);
const reduceMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const ICONS = {
  heart: '<path d="M12 20s-7-4.4-9-9.2C1.7 7.3 4 4.5 7 4.5c2 0 3.6 1.1 5 3 1.4-1.9 3-3 5-3 3 0 5.3 2.8 4 6.3-2 4.800-9 9.200-9 9.200z"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
  eye: '<path d="M2 12s3.600-7 10-7 10 7 10 7-3.600 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  pen: '<path d="M12 20h9"/><path d="M16.500 3.500a2.100 2.100 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.300-4.300"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.900 4.900l1.400 1.400M17.700 17.700l1.400 1.400M2 12h2M20 12h2M4.900 19.100l1.400-1.400M17.700 6.300l1.400-1.400"/>',
  moon: '<path d="M21 12.800A9 9 0 1 1 11.200 3a7 7 0 0 0 9.800 9.800z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v5M14 11v5"/>',
  edit: '<path d="M12 20h9"/><path d="M16.500 3.500a2.100 2.100 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.500.5l3-3a5 5 0 0 0-7-7l-1.700 1.700"/><path d="M14 11a5 5 0 0 0-7.500-.5l-3 3a5 5 0 0 0 7 7l1.700-1.700"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.500"/><rect x="14" y="3" width="7" height="7" rx="1.500"/><rect x="3" y="14" width="7" height="7" rx="1.500"/><rect x="14" y="14" width="7" height="7" rx="1.500"/>',
  shield: '<path d="M12 3 4 6v6c0 4.500 3.400 8 8 9 4.600-1 8-4.500 8-9V6z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  ink: '<path d="M12 3c4 5 6 8 6 11a6 6 0 0 1-12 0c0-3 2-6 6-11z"/>',
};
const ico = (n, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

const squig = '<svg class="squig" viewBox="0 0 120 12" aria-hidden="true"><path d="M2 8 C 14 1, 22 1, 32 7 S 52 13, 62 6 S 84 0, 94 6 S 112 10, 118 4" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>';

function when(iso) {
  if (!iso) return '';
  const d = new Date(iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z');
  return isNaN(d) ? '' : d;
}
function ago(iso) {
  const d = when(iso);
  if (!d) return '';
  const s = (Date.now() - d.getTime()) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  if (s < 86400 * 7) return Math.floor(s / 86400) + ' d ago';
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: d.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
}
const fmtDate = (iso) => { const d = when(iso); return d ? d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' }) : ''; };
const num = (n) => Number(n || 0).toLocaleString();

function avatar(name, cls = '') {
  let h = 0;
  for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return `<span class="avatar ${cls}" style="background:hsl(${h} 62% 52%)" aria-hidden="true">${esc(String(name).charAt(0))}</span>`;
}

/* ============ Generated covers ============ */
const PAL = [
  ['#5b4bff', '#ff4d8d', '#ffc857'], ['#0ea5e9', '#5b4bff', '#a5f3fc'], ['#ff7a59', '#ffc857', '#ff4d8d'], ['#10b981', '#0ea5e9', '#d9f99d'],
  ['#7c3aed', '#db2777', '#fbcfe8'], ['#0f766e', '#1d4ed8', '#67e8f9'], ['#f43f5e', '#f59e0b', '#fde68a'], ['#1e1b4b', '#5b4bff', '#22d3ee'],
];
let coverN = 0;
function cover(i) {
  const v = ((Number(i) || 0) % 8 + 8) % 8, [a, b, c] = PAL[v], id = 'cg' + coverN++;
  const shapes = [
    `<g fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="2">${[60, 110, 160, 210, 260].map((r) => `<circle cx="600" cy="140" r="${r}"/>`).join('')}</g><circle cx="600" cy="140" r="34" fill="${c}"/>`,
    `<g fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="3">${[0, 1, 2, 3, 4].map((k) => `<path d="M-20 ${250 + k * 28} C 150 ${190 + k * 28}, 300 ${320 + k * 28}, 460 ${250 + k * 28} S 700 ${190 + k * 28}, 840 ${260 + k * 28}"/>`).join('')}</g>`,
    `<circle cx="560" cy="230" r="120" fill="${c}" opacity=".9"/>${[0, 1, 2, 3].map((k) => `<rect x="0" y="${300 + k * 26}" width="800" height="${10 + k * 4}" fill="#fff" opacity="${(.35 - k * .06).toFixed(2)}"/>`).join('')}`,
    `<g fill="#fff" fill-opacity=".5">${Array.from({ length: 60 }, (_, k) => `<circle cx="${60 + (k % 10) * 72}" cy="${50 + Math.floor(k / 10) * 68}" r="${3 + ((k * 7) % 5)}"/>`).join('')}</g>`,
    `<circle cx="220" cy="300" r="170" fill="${c}" opacity=".55"/><circle cx="470" cy="170" r="130" fill="#fff" opacity=".22"/><circle cx="640" cy="320" r="100" fill="${a}" opacity=".5"/>`,
    `<g fill="#fff">${[0, 1, 2, 3, 4, 5].map((k) => `<polygon points="${k * 140 - 60},450 ${k * 140 + 20},450 ${k * 140 + 300},0 ${k * 140 + 220},0" opacity="${(.07 + (k % 3) * .06).toFixed(2)}"/>`).join('')}</g>`,
    `<g fill="none" stroke="#fff" stroke-width="14" stroke-linecap="round" stroke-opacity=".4">${[0, 1, 2].map((k) => `<path d="M${100 + k * 60} 450 A ${200 + k * 60} ${200 + k * 60} 0 0 1 ${700 - k * 20} ${450 - k * 30}"/>`).join('')}</g>`,
    `<g fill="#fff">${Array.from({ length: 28 }, (_, k) => `<circle cx="${(k * 137) % 780 + 10}" cy="${(k * 89) % 420 + 10}" r="${1 + (k % 3)}" opacity="${(.3 + (k % 4) * .15).toFixed(2)}"/>`).join('')}</g><circle cx="620" cy="130" r="60" fill="none" stroke="${c}" stroke-width="3"/>`,
  ];
  return `<svg viewBox="0 0 800 450" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="800" height="450" fill="url(#${id})"/>${shapes[v]}</svg>`;
}

/* ============ Markdown (escapes first, so it can't inject HTML) ============ */
function inline(s) {
  return s
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}
function md(src) {
  const lines = esc(src).replace(/\r/g, '').split('\n');
  const out = [];
  let i = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (/^```/.test(ln)) {
      const buf = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      out.push(`<pre><code>${buf.join('\n')}</code></pre>`);
    } else if (/^#{1,3}\s/.test(ln)) {
      const lvl = Math.min(3, ln.match(/^#+/)[0].length) + (ln.startsWith('# ') ? 1 : 0);
      out.push(`<h${lvl}>${inline(ln.replace(/^#+\s*/, ''))}</h${lvl}>`);
      i++;
    } else if (/^---+\s*$/.test(ln)) { out.push('<hr>'); i++; }
    else if (/^&gt;\s?/.test(ln)) {
      const buf = [];
      while (i < lines.length && /^&gt;\s?/.test(lines[i])) buf.push(lines[i++].replace(/^&gt;\s?/, ''));
      out.push(`<blockquote>${inline(buf.join(' '))}</blockquote>`);
    } else if (/^[-*]\s+/.test(ln)) {
      const buf = [];
      while (i < lines.length && /^[-*]\s+/.test(lines[i])) buf.push(`<li>${inline(lines[i++].replace(/^[-*]\s+/, ''))}</li>`);
      out.push(`<ul>${buf.join('')}</ul>`);
    } else if (/^\d+\.\s+/.test(ln)) {
      const buf = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i])) buf.push(`<li>${inline(lines[i++].replace(/^\d+\.\s+/, ''))}</li>`);
      out.push(`<ol>${buf.join('')}</ol>`);
    } else if (!ln.trim()) i++;
    else {
      const buf = [];
      while (i < lines.length && lines[i].trim() && !/^(```|#{1,3}\s|---+\s*$|&gt;|[-*]\s|\d+\.\s)/.test(lines[i])) buf.push(lines[i++]);
      out.push(`<p>${inline(buf.join(' '))}</p>`);
    }
  }
  return out.join('\n');
}

/* ============ API ============ */
async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    if (res.status === 401 && state.token) signOut(true);
    throw new Error((data && data.error) || 'Something went wrong. Try again.');
  }
  return data;
}

/* ============ UI atoms: toast, modal ============ */
function toast(msg, err = false) {
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : '');
  t.setAttribute('role', err ? 'alert' : 'status');
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, 2800);
}
function confirmBox({ title, text, label = 'Delete', danger = true }) {
  return new Promise((resolve) => {
    const host = $('#modalHost');
    const scrim = document.createElement('div');
    scrim.className = 'scrim';
    scrim.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-labelledby="mt"><h3 id="mt">${esc(title)}</h3><p>${esc(text)}</p><div class="acts"><button class="btn btn-ghost" data-x="0">Cancel</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-x="1">${esc(label)}</button></div></div>`;
    host.appendChild(scrim);
    const done = (v) => { document.removeEventListener('keydown', key); scrim.remove(); resolve(v); };
    const key = (e) => { if (e.key === 'Escape') done(false); };
    document.addEventListener('keydown', key);
    scrim.addEventListener('click', (e) => { if (e.target === scrim) done(false); const b = e.target.closest('[data-x]'); if (b) done(b.dataset.x === '1'); });
    $('[data-x="0"]', scrim).focus();
  });
}
function celebrate(btn) {
  if (reduceMotion()) return;
  const colors = ['#ff4d8d', '#5b4bff', '#ffc857', '#22d3ee'];
  for (let i = 0; i < 10; i++) {
    const d = document.createElement('i');
    d.className = 'drop';
    const a = (Math.PI * 2 * i) / 10, r = 34 + Math.random() * 20;
    d.style.cssText = `--c:${colors[i % 4]};--x:${Math.cos(a) * r}px;--y:${Math.sin(a) * r}px`;
    btn.appendChild(d);
    setTimeout(() => d.remove(), 800);
  }
}

/* ============ Motion helpers ============ */
function setupReveal(root = document) {
  const els = $$('.reveal:not(.in)', root);
  if (!els.length) return;
  if (reduceMotion() || !('IntersectionObserver' in window)) { els.forEach((e) => e.classList.add('in')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      const el = en.target;
      io.unobserve(el);
      el.classList.add('in');
      // drop the stagger delay afterwards so hover transitions stay instant
      setTimeout(() => { if (el.classList.contains('card')) el.classList.remove('reveal', 'in'); else el.style.transitionDelay = '0ms'; }, 1500);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  els.forEach((el, i) => { el.style.setProperty('--d', (i % 6) * 70 + 'ms'); io.observe(el); });
  onCleanup(() => io.disconnect());
}
function countUp(el) {
  const to = Number(el.dataset.to || 0);
  if (reduceMotion() || to === 0) { el.textContent = num(to); return; }
  const t0 = performance.now(), dur = 1100;
  const step = (t) => {
    const p = Math.min(1, (t - t0) / dur);
    el.textContent = num(Math.round(to * (1 - Math.pow(1 - p, 3))));
    if (p < 1 && el.isConnected) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
const runCounts = (root) => $$('[data-to]', root).forEach(countUp);

/* ============ Shell: nav, theme, mount ============ */
function renderNav() {
  const u = state.user, dark = document.documentElement.dataset.theme === 'dark';
  $('#navRight').innerHTML = `
    <a class="nav-link hide-s" href="#/">Read</a>
    ${u ? `<a class="btn btn-primary btn-sm" href="#/write">${ico('pen', 'sm')}Write</a>` : `<a class="nav-link" href="#/login">Sign in</a><a class="btn btn-primary btn-sm" href="#/register">Join free</a>`}
    <button class="icon-btn" id="themeBtn" aria-label="Switch to ${dark ? 'light' : 'dark'} theme">${ico(dark ? 'sun' : 'moon')}</button>
    ${u ? `<div class="menu"><button class="icon-btn" id="menuBtn" aria-haspopup="true" aria-expanded="false" aria-label="Account menu">${avatar(u.username)}</button></div>` : ''}`;
}
function toggleMenu() {
  const old = $('.menu-panel');
  if (old) { old.remove(); $('#menuBtn').setAttribute('aria-expanded', 'false'); return; }
  const u = state.user;
  const p = document.createElement('div');
  p.className = 'menu-panel';
  p.innerHTML = `<div class="menu-head"><b>${esc(u.username)}</b><span>${esc(u.email)}</span></div>
    <a href="#/dashboard">${ico('grid')}Your articles</a>
    <a href="#/u/${esc(u.username)}">${ico('user')}Public profile</a>
    ${u.role === 'admin' ? `<a href="#/admin">${ico('shield')}Admin</a>` : ''}
    <button data-act="signout">${ico('out')}Sign out</button>`;
  $('.menu').appendChild(p);
  $('#menuBtn').setAttribute('aria-expanded', 'true');
}
document.addEventListener('click', (e) => {
  if (e.target.closest('#themeBtn')) {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    store.set('ink_theme', next);
    renderNav();
    return;
  }
  if (e.target.closest('#menuBtn')) { toggleMenu(); return; }
  if (e.target.closest('[data-act="signout"]')) { signOut(); return; }
  if (!e.target.closest('.menu-panel')) { const p = $('.menu-panel'); if (p) { p.remove(); $('#menuBtn')?.setAttribute('aria-expanded', 'false'); } }
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { const p = $('.menu-panel'); if (p) { p.remove(); $('#menuBtn')?.focus(); } } });

function signOut(expired) {
  state.token = null; state.user = null;
  store.del('ink_token');
  renderNav();
  toast(expired ? 'Your session ended. Sign in again.' : 'Signed out.');
  location.hash = '#/';
}
function setSession(data) {
  state.token = data.token; state.user = data.user;
  store.set('ink_token', data.token);
  renderNav();
}

function mount(html, { focus = true } = {}) {
  const app = $('#app');
  app.innerHTML = `<div class="page">${html}</div>`;
  window.scrollTo({ top: 0, behavior: 'auto' });
  setupReveal(app);
  runCounts(app);
  if (focus) app.focus({ preventScroll: true });
}
const needAuth = () => { if (!state.user) { location.hash = '#/login'; return false; } return true; };

/* ============ Post card ============ */
function card(p, featured = false) {
  return `<article class="card reveal${featured ? ' featured' : ''}">
    <a class="card-cover" href="#/post/${esc(p.slug)}" tabindex="-1" aria-hidden="true">${cover(p.cover)}${p.category ? `<span class="cat" style="--c:${esc(p.category_color)}">${esc(p.category)}</span>` : ''}</a>
    <div class="card-body">
      <h3><a href="#/post/${esc(p.slug)}">${esc(p.title)}</a></h3>
      <p class="excerpt">${esc(p.excerpt)}</p>
      <div class="card-meta">
        <a class="by" href="#/u/${esc(p.author)}">${avatar(p.author, 'sm')}${esc(p.author)}</a>
        <span class="counts"><span title="Likes">${ico('heart', 'sm')}${p.likes}</span><span title="Comments">${ico('chat', 'sm')}${p.comment_count}</span><span>${esc(ago(p.published_at || p.created_at))}</span></span>
      </div>
    </div>
  </article>`;
}
const emptyState = (title, text, btn) => `<div class="empty">${ico('ink')}<h3>${esc(title)}</h3><p>${esc(text)}</p>${btn || ''}</div>`;

/* ============ Pages ============ */
function parseQuery(s) { const p = {}; new URLSearchParams(s).forEach((v, k) => { p[k] = v; }); return p; }
const buildHash = (q) => { const s = new URLSearchParams(Object.entries(q).filter(([, v]) => v)).toString(); return '#/' + (s ? '?' + s : ''); };

async function home(q) {
  const [cats, tags, meta] = await Promise.all([api('/categories'), api('/tags'), api('/meta')]);
  state.cats = cats;
  const words = 'Write something worth rereading.'.split(' ');
  mount(`
    <section class="hero" id="hero">
      <canvas id="ink"></canvas>
      <div class="hero-inner">
        <h1 class="hero-title" aria-label="Write something worth rereading.">${words.map((w, i) => `<span class="w" aria-hidden="true"><span style="--i:${i}">${esc(w)}</span></span>`).join('')}</h1>
        <p class="hero-sub">Inkwell is where people publish what they think. Write an article, join the conversation, and find voices worth following.</p>
        <div class="hero-cta">
          <a class="btn btn-primary" href="${state.user ? '#/write' : '#/register'}">${state.user ? 'Write an article' : 'Start writing'}</a>
          <button class="btn btn-ghost" data-scroll="#feed">Read the latest</button>
        </div>
        <form class="hero-search" id="heroSearch" role="search">
          <input name="q" type="search" placeholder="Search articles, topics, writers" aria-label="Search articles" value="${esc(q.q || '')}" maxlength="80">
          <button class="btn btn-primary" type="submit">${ico('search', 'sm')}Search</button>
        </form>
        <div class="stats">
          <div class="stat"><b data-to="${meta.articles}">0</b><span>articles published</span></div>
          <div class="stat"><b data-to="${meta.writers}">0</b><span>writers</span></div>
          <div class="stat"><b data-to="${meta.comments}">0</b><span>comments</span></div>
          <div class="stat"><b data-to="${meta.reads}">0</b><span>reads</span></div>
        </div>
      </div>
    </section>
    <section class="section wrap" id="feed">
      <div class="sec-head reveal"><div><h2>${q.q ? 'Search results' : 'Latest articles'}</h2>${squig}</div>
        <select class="input sort" id="sort" aria-label="Sort articles">
          <option value="new">Newest</option><option value="popular">Most read</option><option value="liked">Most liked</option>
        </select></div>
      <div class="toolbar reveal"><div class="chips" id="chips">
        <button class="chip ${!q.category ? 'on' : ''}" data-cat="">All</button>
        ${cats.map((c) => `<button class="chip ${q.category === c.slug ? 'on' : ''}" data-cat="${esc(c.slug)}" style="--c:${esc(c.color)}"><i></i>${esc(c.name)}</button>`).join('')}
      </div></div>
      ${tags.length ? `<div class="tagcloud reveal">${tags.slice(0, 14).map((t) => `<a class="tag ${q.tag === t.slug ? 'on' : ''}" href="${buildHash({ ...q, tag: q.tag === t.slug ? '' : t.slug })}">#${esc(t.name)}</a>`).join('')}</div>` : ''}
      ${(q.q || q.tag || q.category) ? `<div class="result-note" id="note"></div>` : ''}
      <div class="grid" id="grid">${'<div class="skel"></div>'.repeat(3)}</div>
      <div class="more" id="more"></div>
    </section>`, { focus: false });

  $('#sort').value = q.sort || 'new';
  window.Ink.start($('#ink'));
  onCleanup(() => window.Ink.stop());

  let page = 1;
  const grid = $('#grid'), more = $('#more');
  async function load(reset) {
    if (reset) { page = 1; grid.innerHTML = '<div class="skel"></div>'.repeat(3); }
    const params = new URLSearchParams({ ...(q.q && { q: q.q }), ...(q.category && { category: q.category }), ...(q.tag && { tag: q.tag }), sort: q.sort || 'new', page, limit: 9 });
    try {
      const d = await api('/posts?' + params);
      if (reset) grid.innerHTML = '';
      if (!d.posts.length && reset) {
        grid.innerHTML = emptyState('No articles found', q.q ? `Nothing matches “${q.q}”. Try a different word, or clear the search.` : 'Nobody has published here yet. Be the first.', `<a class="btn btn-primary" href="${state.user ? '#/write' : '#/register'}">Write an article</a>`);
        grid.style.display = 'block';
      } else {
        grid.style.display = '';
        const first = reset && page === 1 && !q.q && !q.tag && !q.category && !q.sort;
        grid.insertAdjacentHTML('beforeend', d.posts.map((p, i) => card(p, first && i === 0)).join(''));
        setupReveal(grid);
      }
      const note = $('#note');
      if (note) note.innerHTML = `<span>${d.total} ${d.total === 1 ? 'article' : 'articles'} found</span><a class="linkish" href="#/">Clear filters</a>`;
      more.innerHTML = d.page < d.pages ? '<button class="btn btn-ghost" id="loadMore">Load more articles</button>' : '';
    } catch (e) { grid.innerHTML = emptyState('Could not load articles', e.message); }
  }
  load(true);

  $('#heroSearch').addEventListener('submit', (e) => { e.preventDefault(); location.hash = buildHash({ ...q, q: new FormData(e.target).get('q').trim() }); });
  $('#chips').addEventListener('click', (e) => { const b = e.target.closest('[data-cat]'); if (b) location.hash = buildHash({ ...q, category: b.dataset.cat }); });
  $('#sort').addEventListener('change', (e) => { location.hash = buildHash({ ...q, sort: e.target.value === 'new' ? '' : e.target.value }); });
  more.addEventListener('click', async (e) => {
    const b = e.target.closest('#loadMore'); if (!b) return;
    b.disabled = true; b.innerHTML = '<span class="spin"></span>Loading'; page++; await load(false);
  });
  $('[data-scroll]').addEventListener('click', (e) => $(e.currentTarget.dataset.scroll).scrollIntoView({ behavior: reduceMotion() ? 'auto' : 'smooth' }));
}

async function postPage(slug) {
  const p = await api('/posts/' + slug);
  const comments = p.status === 'published' ? await api(`/posts/${p.id}/comments`) : [];
  const mine = state.user && (state.user.id === p.author_id);
  const isAdmin = state.user && state.user.role === 'admin';
  const renderComments = () => comments.map((c) => `
    <div class="comment" data-id="${c.id}">${avatar(c.username)}
      <div class="body"><div class="who"><b>${esc(c.username)}</b><span>${esc(ago(c.created_at))}</span>
        ${state.user && (state.user.id === c.user_id || isAdmin) ? `<button class="linkish" data-del-comment="${c.id}" style="margin-left:auto;font-weight:500;color:var(--muted)">Delete</button>` : ''}</div>
        <p>${esc(c.body)}</p></div></div>`).join('') || '<p style="color:var(--muted)">No comments yet. Start the conversation.</p>';

  mount(`
    <article class="article">
      ${p.status !== 'published' ? `<p class="signin-note" style="margin-bottom:1.5rem">This article is a <b>${esc(p.status)}</b>. Only you${isAdmin && !mine ? ' and other admins' : ''} can see it.</p>` : ''}
      <header class="a-head">
        ${p.category ? `<a class="crumb" style="--c:${esc(p.category_color)}" href="#/?category=${esc(p.category_slug)}">${esc(p.category)}</a>` : ''}
        <h1>${esc(p.title)}</h1>
        <div class="a-meta">
          <a class="by" href="#/u/${esc(p.author)}">${avatar(p.author)}${esc(p.author)}</a>
          <span>${esc(fmtDate(p.published_at || p.created_at))}</span>
          <span>${p.read_minutes} min read</span>
          <span style="display:inline-flex;gap:.35rem;align-items:center">${ico('eye', 'sm')}${num(p.views)}</span>
        </div>
      </header>
      <div class="a-cover">${cover(p.cover)}</div>
      <div class="prose">${md(p.content)}</div>
      ${p.tags.length ? `<div class="a-tags">${p.tags.map((t) => `<a class="tag" href="#/?tag=${esc(t.replace(/[^\w-]+/g, '-'))}">#${esc(t)}</a>`).join('')}</div>` : ''}
      <div class="a-actions">
        <button class="btn btn-ghost like ${p.liked ? 'on' : ''}" id="likeBtn" aria-pressed="${p.liked}">${ico('heart')}<span id="likeN">${p.likes}</span></button>
        <button class="btn btn-ghost" id="copyBtn">${ico('link')}Copy link</button>
        <span class="spacer"></span>
        ${mine || isAdmin ? `<a class="btn btn-ghost" href="#/write/${p.id}">${ico('edit')}Edit</a>` : ''}
      </div>
      <a class="author-card reveal" href="#/u/${esc(p.author)}">${avatar(p.author, 'lg')}<div><small style="color:var(--muted)">Written by</small><h3>${esc(p.author)}</h3><p>Read more from this writer.</p></div></a>
      ${p.status === 'published' ? `<section class="comments reveal">
        <h2><span id="cCount">${comments.length}</span> ${comments.length === 1 ? 'comment' : 'comments'}</h2>
        ${state.user ? `<form id="cForm" class="field"><label for="cBody" class="sr">Add a comment</label><textarea class="input" id="cBody" maxlength="1000" placeholder="Share a thought or ask a question"></textarea><div class="form-error" id="cErr" role="alert"></div><div><button class="btn btn-primary btn-sm" type="submit">Post comment</button></div></form>`
          : `<div class="signin-note"><a href="#/login">Sign in</a> or <a href="#/register">create an account</a> to comment.</div>`}
        <div id="cList">${renderComments()}</div></section>` : ''}
    </article>`);
  document.title = p.title + ' · Inkwell';

  // reading progress bar
  const bar = $('#progress'), art = $('.prose');
  const onScroll = () => {
    const r = art.getBoundingClientRect(), total = r.height - window.innerHeight * 0.6;
    bar.style.width = Math.max(0, Math.min(1, -r.top / Math.max(total, 1))) * 100 + '%';
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  onCleanup(() => { window.removeEventListener('scroll', onScroll); bar.style.width = '0'; });

  const likeBtn = $('#likeBtn');
  likeBtn.addEventListener('click', async () => {
    if (!state.user) { toast('Sign in to like articles.', true); return; }
    if (p.status !== 'published') return;
    try {
      const r = await api(`/posts/${p.id}/like`, { method: 'POST' });
      likeBtn.classList.toggle('on', r.liked);
      likeBtn.setAttribute('aria-pressed', r.liked);
      $('#likeN').textContent = r.likes;
      if (r.liked) { likeBtn.classList.remove('pop'); void likeBtn.offsetWidth; likeBtn.classList.add('pop'); celebrate(likeBtn); }
    } catch (e) { toast(e.message, true); }
  });
  $('#copyBtn').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(location.href); toast('Link copied.'); } catch { toast('Copy failed. Copy the address bar instead.', true); }
  });

  const form = $('#cForm');
  if (form) form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = $('#cBody').value.trim(), btn = $('button', form);
    if (body.length < 2) { $('#cErr').textContent = 'Write a comment before posting.'; return; }
    btn.disabled = true;
    try {
      const c = await api(`/posts/${p.id}/comments`, { method: 'POST', body: { body } });
      comments.push(c);
      $('#cList').innerHTML = renderComments();
      $('#cCount').textContent = comments.length;
      $('#cBody').value = ''; $('#cErr').textContent = '';
      toast('Comment posted.');
    } catch (err) { $('#cErr').textContent = err.message; }
    btn.disabled = false;
  });
  $('#cList')?.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-del-comment]'); if (!b) return;
    if (!(await confirmBox({ title: 'Delete this comment?', text: 'This can’t be undone.' }))) return;
    try {
      await api('/comments/' + b.dataset.delComment, { method: 'DELETE' });
      comments.splice(comments.findIndex((c) => c.id == b.dataset.delComment), 1);
      $('#cList').innerHTML = renderComments();
      $('#cCount').textContent = comments.length;
      toast('Comment deleted.');
    } catch (err) { toast(err.message, true); }
  });
}

async function editor(id) {
  if (!needAuth()) return;
  let post = null;
  const cats = state.cats.length ? state.cats : (state.cats = await api('/categories'));
  if (id) {
    const mine = await api('/my/posts');
    const found = mine.find((x) => x.id == id) || (state.user.role === 'admin' ? (await api('/admin/posts')).find((x) => x.id == id) : null);
    if (!found) throw new Error('You can only edit your own articles.');
    post = await api('/posts/' + found.slug);
  }
  const draftKey = 'ink_draft_new';
  let saved = null;
  if (!post) { try { saved = JSON.parse(store.get(draftKey) || 'null'); } catch { saved = null; } }
  const v = post || saved || { title: '', content: '', excerpt: '', tags: [], cover: 0, category: null };
  let tags = [...(v.tags || [])], coverIdx = v.cover || 0, editId = post ? post.id : null, status = post ? post.status : 'draft';
  const catId = post ? (cats.find((c) => c.name === post.category) || {}).id : v.category_id;

  mount(`
    <div class="editor wrap">
      <div class="ed-top"><h1>${post ? 'Edit article' : 'New article'}</h1>
        <div class="ed-actions">
          <button class="btn btn-ghost" id="saveDraft">Save draft</button>
          <button class="btn btn-primary" id="publish">${post && post.status === 'published' ? 'Update article' : 'Publish'}</button>
        </div></div>
      <label class="sr" for="title">Title</label>
      <input class="ed-title" id="title" maxlength="140" placeholder="Give it a title" value="${esc(v.title)}" autocomplete="off">
      <div class="form-error" id="edErr" role="alert"></div>
      <div class="ed-grid">
        <div class="ed-pane">
          <div class="tb" role="toolbar" aria-label="Formatting">
            <button type="button" data-fmt="b" title="Bold"><b>B</b></button><button type="button" data-fmt="i" title="Italic"><i>I</i></button>
            <button type="button" data-fmt="h" title="Heading">H</button><button type="button" data-fmt="q" title="Quote">“</button>
            <button type="button" data-fmt="ul" title="List">•</button><button type="button" data-fmt="code" title="Code">&lt;/&gt;</button>
            <button type="button" data-fmt="a" title="Link">${ico('link', 'sm')}</button>
          </div>
          <label class="sr" for="body">Article body in Markdown</label>
          <textarea class="ed-text" id="body" placeholder="Start writing. Markdown works: ## headings, **bold**, *italic*, > quotes, - lists.">${esc(v.content)}</textarea>
          <div class="ed-foot"><span id="wc">0 words</span><span id="rt"></span></div>
        </div>
        <div class="ed-pane"><div class="tb"><span style="padding:.5rem .6rem;font-weight:600;color:var(--muted)">Live preview</span></div>
          <div class="ed-prev"><div class="prose" id="prev"></div></div></div>
      </div>
      <div class="ed-meta">
        <div><div class="field"><label for="cat">Category</label>
          <select class="input" id="cat"><option value="">No category</option>${cats.map((c) => `<option value="${c.id}" ${catId == c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
          <div class="field"><label for="tagIn">Tags</label><div class="tagbox" id="tagbox"><input id="tagIn" placeholder="Type a tag, press Enter" maxlength="24"></div><span class="hint">Up to 6 tags.</span></div></div>
        <div><div class="field"><label for="exc">Summary <span class="hint">(optional, shown on cards)</span></label><textarea class="input" id="exc" maxlength="240" style="min-height:74px">${esc(post ? post.excerpt : v.excerpt || '')}</textarea></div>
          <div class="field"><label>Cover</label><div class="covers" id="covers">${Array.from({ length: 8 }, (_, i) => `<button type="button" data-c="${i}" class="${i === coverIdx ? 'on' : ''}" aria-label="Cover ${i + 1}">${cover(i)}</button>`).join('')}</div></div></div>
      </div>
    </div>`);

  const body = $('#body'), prev = $('#prev'), title = $('#title');
  let t;
  const refresh = () => {
    const words = body.value.trim() ? body.value.trim().split(/\s+/).length : 0;
    $('#wc').textContent = `${words} ${words === 1 ? 'word' : 'words'}`;
    $('#rt').textContent = `${Math.max(1, Math.round(words / 210))} min read`;
    prev.innerHTML = body.value.trim() ? md(body.value) : '<p class="ph">Your article appears here as you type.</p>';
  };
  refresh();
  const drawTags = () => {
    $$('.pill', $('#tagbox')).forEach((n) => n.remove());
    tags.forEach((tg, i) => $('#tagbox').insertBefore(Object.assign(document.createElement('span'), { className: 'pill', innerHTML: `${esc(tg)}<button type="button" data-rm="${i}" aria-label="Remove tag ${esc(tg)}">×</button>` }), $('#tagIn')));
  };
  drawTags();
  const autosave = () => { if (!post) store.set(draftKey, JSON.stringify({ title: title.value, content: body.value, excerpt: $('#exc').value, tags, cover: coverIdx, category_id: $('#cat').value })); };
  body.addEventListener('input', () => { clearTimeout(t); t = setTimeout(refresh, 120); autosave(); });
  [title, $('#exc'), $('#cat')].forEach((el) => el.addEventListener('input', autosave));
  $('#tagIn').addEventListener('keydown', (e) => {
    const inp = e.target;
    if ((e.key === 'Enter' || e.key === ',') && inp.value.trim()) {
      e.preventDefault();
      const tg = inp.value.trim().replace(/,/g, '').toLowerCase();
      if (tags.length < 6 && !tags.includes(tg)) { tags.push(tg); drawTags(); autosave(); }
      inp.value = '';
    } else if (e.key === 'Backspace' && !inp.value && tags.length) { tags.pop(); drawTags(); }
  });
  $('#tagbox').addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) { tags.splice(Number(b.dataset.rm), 1); drawTags(); } });
  $('#covers').addEventListener('click', (e) => {
    const b = e.target.closest('[data-c]'); if (!b) return;
    coverIdx = Number(b.dataset.c);
    $$('#covers button').forEach((x) => x.classList.toggle('on', x === b)); autosave();
  });
  $('.tb').addEventListener('click', (e) => {
    const b = e.target.closest('[data-fmt]'); if (!b) return;
    const s = body.selectionStart, en = body.selectionEnd, sel = body.value.slice(s, en);
    const wrap = (a, z, ph) => { const txt = sel || ph; body.setRangeText(a + txt + z, s, en, 'end'); body.setSelectionRange(s + a.length, s + a.length + txt.length); };
    const line = (pre, ph) => { const txt = sel || ph; body.setRangeText((s && body.value[s - 1] !== '\n' ? '\n' : '') + pre + txt, s, en, 'end'); };
    ({ b: () => wrap('**', '**', 'bold text'), i: () => wrap('*', '*', 'italic text'), code: () => wrap('`', '`', 'code'), h: () => line('## ', 'Heading'), q: () => line('> ', 'A memorable line'), ul: () => line('- ', 'List item'), a: () => wrap('[', '](https://)', 'link text') })[b.dataset.fmt]();
    body.focus(); refresh(); autosave();
  });

  async function save(publish) {
    const err = $('#edErr'), btn = publish ? $('#publish') : $('#saveDraft');
    err.textContent = '';
    const payload = { title: title.value, content: body.value, excerpt: $('#exc').value, category_id: $('#cat').value || null, tags, cover: coverIdx, status: publish ? 'published' : (status === 'published' ? 'published' : 'draft') };
    const label = btn.textContent; btn.disabled = true; btn.innerHTML = '<span class="spin"></span>Saving';
    try {
      const r = editId ? await api('/posts/' + editId, { method: 'PUT', body: payload }) : await api('/posts', { method: 'POST', body: payload });
      editId = r.id; status = r.status; store.del(draftKey);
      if (publish) { toast(r.status === 'published' ? 'Published.' : 'Saved.'); location.hash = '#/post/' + r.slug; }
      else { toast('Draft saved.'); history.replaceState(null, '', '#/write/' + r.id); }
    } catch (e) { err.textContent = e.message; }
    btn.disabled = false; btn.textContent = label;
  }
  $('#saveDraft').addEventListener('click', () => save(false));
  $('#publish').addEventListener('click', () => save(true));
  if (saved) toast('Restored your unsaved draft.');
  title.focus();
}

async function dashboard() {
  if (!needAuth()) return;
  let posts = await api('/my/posts'), tab = 'all';
  const stat = (k) => posts.reduce((a, p) => a + (p[k] || 0), 0);
  const list = () => {
    const rows = posts.filter((p) => tab === 'all' || p.status === tab);
    return rows.length ? rows.map((p, i) => `<div class="row" style="--i:${i}">
      <div class="thumb">${cover(p.cover)}</div>
      <div class="row-main"><h3>${esc(p.title)}</h3><small><span class="status ${esc(p.status)}">${esc(p.status)}</span><span>Updated ${esc(ago(p.updated_at))}</span>
        <span>${ico('eye', 'sm')} ${num(p.views)}</span><span>${ico('heart', 'sm')} ${p.likes}</span><span>${ico('chat', 'sm')} ${p.comment_count}</span></small></div>
      <div class="row-actions">
        ${p.status === 'published' ? `<a class="btn btn-ghost btn-sm" href="#/post/${esc(p.slug)}">View</a>` : ''}
        <a class="btn btn-ghost btn-sm" href="#/write/${p.id}">Edit</a>
        <button class="btn btn-danger btn-sm" data-del="${p.id}" aria-label="Delete ${esc(p.title)}">${ico('trash', 'sm')}</button></div></div>`).join('')
      : emptyState(tab === 'all' ? 'You haven’t written anything yet' : `No ${tab} articles`, tab === 'all' ? 'Your first article is a good place to start.' : 'Switch tabs to see the rest.', tab === 'all' ? '<a class="btn btn-primary" href="#/write">Write your first article</a>' : '');
  };
  mount(`<div class="dash wrap">
    <div class="dash-head"><div><h1>Your articles</h1><p>Hello, ${esc(state.user.username)}. Here is how your writing is doing.</p></div><a class="btn btn-primary" href="#/write">${ico('plus', 'sm')}New article</a></div>
    <div class="tiles">
      <div class="tile reveal"><b data-to="${posts.filter((p) => p.status === 'published').length}">0</b><span>Published</span></div>
      <div class="tile reveal"><b data-to="${posts.filter((p) => p.status === 'draft').length}">0</b><span>Drafts</span></div>
      <div class="tile reveal"><b data-to="${stat('views')}">0</b><span>Total reads</span></div>
      <div class="tile reveal"><b data-to="${stat('likes')}">0</b><span>Likes received</span></div></div>
    <div class="tabs" role="tablist">${['all', 'published', 'draft'].map((t) => `<button role="tab" data-tab="${t}" class="${t === 'all' ? 'on' : ''}">${t === 'all' ? 'All' : t === 'draft' ? 'Drafts' : 'Published'}</button>`).join('')}</div>
    <div class="rows" id="rows">${list()}</div></div>`);
  $('.tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]'); if (!b) return;
    tab = b.dataset.tab; $$('.tabs button').forEach((x) => x.classList.toggle('on', x === b)); $('#rows').innerHTML = list();
  });
  $('#rows').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-del]'); if (!b) return;
    if (!(await confirmBox({ title: 'Delete this article?', text: 'The article and its comments will be removed for good.' }))) return;
    try { await api('/posts/' + b.dataset.del, { method: 'DELETE' }); posts = posts.filter((p) => p.id != b.dataset.del); $('#rows').innerHTML = list(); toast('Article deleted.'); }
    catch (err) { toast(err.message, true); }
  });
}

async function profile(name) {
  const [u, d] = await Promise.all([api('/users/' + name), api('/posts?author=' + encodeURIComponent(name) + '&limit=24')]);
  const me = state.user && state.user.username.toLowerCase() === u.username.toLowerCase();
  mount(`<div class="wrap"><div class="profile-head">${avatar(u.username, 'lg')}<div><h1>${esc(u.username)}</h1>
    <p>${esc(u.bio) || (me ? 'Add a short bio so readers know who you are.' : 'This writer hasn’t added a bio yet.')}</p>
    <div class="profile-stats"><span><b>${u.posts}</b> articles</span><span><b>${num(u.views)}</b> reads</span><span>Joined ${esc(fmtDate(u.created_at))}</span></div></div></div>
    ${me ? `<form id="bioForm" class="field" style="max-width:520px"><label for="bio">Your bio</label><textarea class="input" id="bio" maxlength="280" style="min-height:80px">${esc(u.bio)}</textarea><div><button class="btn btn-ghost btn-sm" type="submit">Save bio</button></div></form>` : ''}
    <div class="section" style="padding-top:1rem"><div class="grid">${d.posts.length ? d.posts.map((p) => card(p)).join('') : ''}</div>${d.posts.length ? '' : emptyState('No articles yet', 'When this writer publishes, their work shows up here.')}</div></div>`);
  $('#bioForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { const r = await api('/auth/me', { method: 'PUT', body: { bio: $('#bio').value } }); state.user = r.user; toast('Bio saved.'); } catch (err) { toast(err.message, true); }
  });
}

function authPage(mode) {
  if (state.user) { location.hash = '#/'; return; }
  const reg = mode === 'register';
  mount(`<div class="auth">
    <aside class="auth-art"><i class="b b1"></i><i class="b b2"></i><i class="b b3"></i>
      <div><blockquote>Start with one honest sentence.</blockquote><cite>Every article on Inkwell began that way.</cite></div></aside>
    <section class="auth-form"><div class="auth-box">
      <h1>${reg ? 'Create your account' : 'Welcome back'}</h1>
      <p>${reg ? 'Free to join. Publish your first article in minutes.' : 'Sign in to write, comment and manage your articles.'}</p>
      <form id="authForm" novalidate>
        ${reg ? '<div class="field"><label for="username">Username</label><input class="input" id="username" name="username" autocomplete="username" maxlength="24" required><span class="hint">3–24 letters, numbers or underscores.</span></div><div class="field"><label for="email">Email</label><input class="input" id="email" name="email" type="email" autocomplete="email" required></div>'
          : '<div class="field"><label for="identifier">Username or email</label><input class="input" id="identifier" name="identifier" autocomplete="username" required></div>'}
        <div class="field"><label for="password">Password</label><input class="input" id="password" name="password" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" required>${reg ? '<span class="hint">At least 8 characters.</span>' : ''}</div>
        <div class="form-error" id="aErr" role="alert"></div>
        <button class="btn btn-primary" type="submit">${reg ? 'Create account' : 'Sign in'}</button>
      </form>
      <p class="auth-alt">${reg ? 'Already have an account? <a href="#/login">Sign in</a>' : 'New here? <a href="#/register">Create an account</a>'}</p>
      ${reg ? '' : '<div class="demo">Want to look around first? <button class="linkish" id="demoFill" type="button">Use the demo account</button></div>'}
    </div></section></div>`);
  $('#demoFill')?.addEventListener('click', () => { $('#identifier').value = 'maya'; $('#password').value = 'password123'; });
  $('#authForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target)), btn = $('button[type=submit]', e.target), err = $('#aErr');
    err.textContent = '';
    const label = btn.textContent; btn.disabled = true; btn.innerHTML = '<span class="spin"></span>One moment';
    try {
      const r = await api(reg ? '/auth/register' : '/auth/login', { method: 'POST', body: f });
      setSession(r);
      toast(reg ? `Welcome to Inkwell, ${r.user.username}.` : `Signed in as ${r.user.username}.`);
      location.hash = reg ? '#/write' : '#/';
    } catch (ex) { err.textContent = ex.message; btn.disabled = false; btn.textContent = label; }
  });
}

/* ---------- Admin ---------- */
async function adminPage() {
  if (!state.user || state.user.role !== 'admin') { toast('Admins only.', true); location.hash = '#/'; return; }
  let tab = 'overview';
  mount(`<div class="dash wrap"><div class="dash-head"><div><h1>Admin</h1><p>Moderate writers, articles and comments.</p></div></div>
    <div class="tabs" role="tablist">${['overview', 'articles', 'comments', 'users', 'categories'].map((t) => `<button role="tab" data-tab="${t}" class="${t === tab ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div>
    <div id="adminBody"></div></div>`);
  const bodyEl = $('#adminBody');
  const statusSel = (cur, opts) => `<select class="input" data-status>${opts.map((o) => `<option ${o === cur ? 'selected' : ''}>${o}</option>`).join('')}</select>`;

  const views = {
    async overview() {
      const s = await api('/admin/stats');
      const days = [];
      for (let i = 13; i >= 0; i--) { const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10); days.push({ d, n: (s.perDay.find((x) => x.d === d) || {}).n || 0 }); }
      const max = Math.max(1, ...days.map((x) => x.n));
      return `<div class="tiles">${[['users', 'Writers'], ['posts', 'Published'], ['drafts', 'Drafts'], ['hidden', 'Hidden'], ['comments', 'Comments'], ['views', 'Total reads']].map(([k, l]) => `<div class="tile reveal"><b data-to="${s[k]}">0</b><span>${l}</span></div>`).join('')}</div>
        <div class="chart"><h3>Articles published, last 14 days</h3><div class="bars" role="img" aria-label="Bar chart of articles published per day">${days.map((x, i) => `<div class="bar ${x.n ? '' : 'zero'}" title="${x.d}: ${x.n}"><span>${x.n || ''}</span><i style="--i:${i};height:${Math.max(4, (x.n / max) * 100)}%"></i><span>${x.d.slice(8)}</span></div>`).join('')}</div></div>`;
    },
    async articles() {
      const rows = await api('/admin/posts');
      return `<div class="table-wrap"><table><thead><tr><th>Title</th><th>Writer</th><th>Status</th><th>Reads</th><th></th></tr></thead><tbody>${rows.map((p, i) => `<tr style="--i:${i}" data-id="${p.id}"><td class="clip"><a href="#/post/${esc(p.slug)}"><b>${esc(p.title)}</b></a></td><td>${esc(p.author)}</td><td>${statusSel(p.status, ['published', 'hidden', 'draft'])}</td><td>${num(p.views)}</td><td><button class="btn btn-danger btn-sm" data-del-post="${p.id}" aria-label="Delete ${esc(p.title)}">${ico('trash', 'sm')}</button></td></tr>`).join('')}</tbody></table></div>`;
    },
    async comments() {
      const rows = await api('/admin/comments');
      if (!rows.length) return emptyState('No comments yet', 'Comments from readers will appear here for review.');
      return `<div class="table-wrap"><table><thead><tr><th>Comment</th><th>Writer</th><th>On article</th><th>Status</th><th></th></tr></thead><tbody>${rows.map((c, i) => `<tr style="--i:${i}" data-id="${c.id}"><td class="clip">${esc(c.body)}</td><td>${esc(c.username)}</td><td class="clip"><a href="#/post/${esc(c.slug)}">${esc(c.post_title)}</a></td><td>${statusSel(c.status, ['visible', 'hidden'])}</td><td><button class="btn btn-danger btn-sm" data-del-comment="${c.id}" aria-label="Delete comment">${ico('trash', 'sm')}</button></td></tr>`).join('')}</tbody></table></div>`;
    },
    async users() {
      const rows = await api('/admin/users');
      return `<div class="table-wrap"><table><thead><tr><th>Writer</th><th>Email</th><th>Articles</th><th>Role</th><th>Status</th></tr></thead><tbody>${rows.map((u, i) => `<tr style="--i:${i}" data-id="${u.id}"><td><span class="by">${avatar(u.username, 'sm')}${esc(u.username)}</span></td><td>${esc(u.email)}</td><td>${u.posts}</td>
        <td>${u.id === state.user.id ? '<span class="status active">you</span>' : `<select class="input" data-role>${['user', 'admin'].map((o) => `<option ${o === u.role ? 'selected' : ''}>${o}</option>`).join('')}</select>`}</td>
        <td>${u.id === state.user.id ? '<span class="status active">active</span>' : statusSel(u.status, ['active', 'banned'])}</td></tr>`).join('')}</tbody></table></div>`;
    },
    async categories() {
      const cats = await api('/categories'); state.cats = cats;
      return `<form class="cat-add" id="catForm"><input class="input" name="name" placeholder="New category name" maxlength="30" required style="max-width:260px" aria-label="Category name"><input type="color" name="color" value="#5b4bff" aria-label="Category color"><button class="btn btn-primary btn-sm" type="submit">Add category</button></form>
        <div class="table-wrap"><table><thead><tr><th>Category</th><th>Articles</th><th></th></tr></thead><tbody>${cats.map((c, i) => `<tr style="--i:${i}"><td><span class="swatch" style="background:${esc(c.color)}"></span>${esc(c.name)}</td><td>${c.count}</td><td><button class="btn btn-danger btn-sm" data-del-cat="${c.id}" aria-label="Delete ${esc(c.name)}">${ico('trash', 'sm')}</button></td></tr>`).join('')}</tbody></table></div>`;
    },
  };
  async function show(t) {
    tab = t;
    $$('.tabs button').forEach((x) => x.classList.toggle('on', x.dataset.tab === t));
    bodyEl.innerHTML = '<div class="skel" style="min-height:220px"></div>';
    try { bodyEl.innerHTML = await views[t](); setupReveal(bodyEl); runCounts(bodyEl); } catch (e) { bodyEl.innerHTML = emptyState('Could not load', e.message); }
  }
  $('.tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) show(b.dataset.tab); });
  const act = async (fn, msg) => { try { await fn(); toast(msg); } catch (e) { toast(e.message, true); } };
  bodyEl.addEventListener('change', async (e) => {
    const tr = e.target.closest('tr'); if (!tr) return;
    const id = tr.dataset.id;
    if (e.target.matches('[data-status]')) {
      const val = e.target.value;
      if (tab === 'articles') await act(() => api('/admin/posts/' + id, { method: 'PATCH', body: { status: val } }), `Article is now ${val}.`);
      else if (tab === 'comments') await act(() => api('/admin/comments/' + id, { method: 'PATCH', body: { status: val } }), `Comment is now ${val}.`);
      else await act(() => api('/admin/users/' + id, { method: 'PATCH', body: { status: val } }), val === 'banned' ? 'Writer suspended.' : 'Writer restored.');
    } else if (e.target.matches('[data-role]')) await act(() => api('/admin/users/' + id, { method: 'PATCH', body: { role: e.target.value } }), `Role changed to ${e.target.value}.`);
  });
  bodyEl.addEventListener('click', async (e) => {
    const dp = e.target.closest('[data-del-post]'), dc = e.target.closest('[data-del-comment]'), dk = e.target.closest('[data-del-cat]');
    if (dp && await confirmBox({ title: 'Delete this article?', text: 'It and all its comments will be removed for good.' })) { await act(() => api('/posts/' + dp.dataset.delPost, { method: 'DELETE' }), 'Article deleted.'); show(tab); }
    if (dc && await confirmBox({ title: 'Delete this comment?', text: 'This can’t be undone.' })) { await act(() => api('/comments/' + dc.dataset.delComment, { method: 'DELETE' }), 'Comment deleted.'); show(tab); }
    if (dk && await confirmBox({ title: 'Delete this category?', text: 'Articles in it stay published but lose their category.' })) { await act(() => api('/admin/categories/' + dk.dataset.delCat, { method: 'DELETE' }), 'Category deleted.'); show(tab); }
  });
  bodyEl.addEventListener('submit', async (e) => {
    if (e.target.id !== 'catForm') return;
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    await act(() => api('/admin/categories', { method: 'POST', body: f }), 'Category added.'); show('categories');
  });
  show('overview');
}

/* ============ Router ============ */
const routes = [
  [/^\/?$/, (_m, q) => home(q)],
  [/^\/post\/([\w-]+)$/, (m) => postPage(m[1])],
  [/^\/write$/, () => editor()],
  [/^\/write\/(\d+)$/, (m) => editor(m[1])],
  [/^\/dashboard$/, () => dashboard()],
  [/^\/admin$/, () => adminPage()],
  [/^\/u\/(\w+)$/, (m) => profile(m[1])],
  [/^\/login$/, () => authPage('login')],
  [/^\/register$/, () => authPage('register')],
];
let navId = 0;
async function route() {
  const id = ++navId;
  cleanups.forEach((fn) => { try { fn(); } catch { /* ignore */ } });
  cleanups = [];
  document.title = 'Inkwell';
  const [path, qs] = (location.hash.slice(1) || '/').split('?');
  const q = parseQuery(qs || '');
  const hit = routes.find(([re]) => re.test(path));
  try {
    if (!hit) {
      mount(emptyState('Page not found', 'That page doesn’t exist, or it moved.', '<a class="btn btn-primary" href="#/">Back to articles</a>'));
    } else await hit[1](path.match(hit[0]), q);
  } catch (e) {
    if (id !== navId) return;
    mount(emptyState('Something went wrong', e.message, '<a class="btn btn-primary" href="#/">Back to articles</a>'));
  }
}
window.addEventListener('hashchange', route);

/* ============ Boot ============ */
(async function boot() {
  if (state.token) {
    try { state.user = (await api('/auth/me')).user; } catch { state.token = null; store.del('ink_token'); }
  }
  renderNav();
  route();
})();
})();
