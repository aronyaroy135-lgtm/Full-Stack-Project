// Runs before first paint so the page never flashes the wrong theme.
(function () {
  var t = null;
  try { t = localStorage.getItem('ink_theme'); } catch (e) {}
  if (!t) t = window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', t);
})();
