// Hero ink canvas: drops of colour bloom where you move or click, and drift away.
(function () {
  var PALETTE = ['91,75,255', '255,77,141', '255,200,87', '34,211,238'];
  var cv, ctx, host, w, h, dpr, raf, last = 0, lastSpawn = 0, lastX = -999, lastY = -999;
  var blots = [], running = false, io, reduce = false, handlers = {};

  function resize() {
    var r = host.getBoundingClientRect();
    dpr = Math.min(2, window.devicePixelRatio || 1);
    w = r.width; h = r.height;
    cv.width = w * dpr; cv.height = h * dpr;
    cv.style.width = w + 'px'; cv.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (reduce) paintStatic();
  }

  function spawn(x, y, big) {
    blots.push({
      x: x, y: y, r: 0, t: 0,
      c: PALETTE[(Math.random() * PALETTE.length) | 0],
      max: (big ? 120 : 52) + Math.random() * (big ? 120 : 60),
      a: big ? 0.5 : 0.36,
      dur: (big ? 2800 : 2100) + Math.random() * 1200,
      dx: (Math.random() - 0.5) * 14, dy: (Math.random() - 0.5) * 14
    });
    if (blots.length > 70) blots.shift();
  }

  function draw(b, alpha) {
    var g = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
    g.addColorStop(0, 'rgba(' + b.c + ',' + alpha + ')');
    g.addColorStop(0.6, 'rgba(' + b.c + ',' + alpha * 0.45 + ')');
    g.addColorStop(1, 'rgba(' + b.c + ',0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 6.2832); ctx.fill();
  }

  function frame(ts) {
    if (!running) return;
    var dt = Math.max(0, Math.min(50, ts - last)); last = ts;
    ctx.clearRect(0, 0, w, h);
    for (var i = blots.length - 1; i >= 0; i--) {
      var b = blots[i];
      b.t += dt;
      var p = b.t / b.dur;
      if (p >= 1) { blots.splice(i, 1); continue; }
      b.r = b.max * (1 - Math.pow(1 - Math.min(1, p * 2.2), 3));
      b.x += b.dx * dt / 1000; b.y += b.dy * dt / 1000;
      draw(b, b.a * (p < 0.35 ? 1 : 1 - (p - 0.35) / 0.65));
    }
    if (ts - lastSpawn > 1000) {
      lastSpawn = ts;
      spawn(Math.random() * w, Math.random() * h, Math.random() < 0.4);
    }
    raf = requestAnimationFrame(frame);
  }

  function paintStatic() {
    ctx.clearRect(0, 0, w, h);
    [[0.78, 0.3, 190, 0], [0.9, 0.75, 140, 1], [0.62, 0.8, 120, 2]].forEach(function (s) {
      draw({ x: w * s[0], y: h * s[1], r: s[2], c: PALETTE[s[3]] }, 0.3);
    });
  }

  function start(canvas) {
    stop();
    cv = canvas; host = canvas.parentElement; ctx = cv.getContext('2d');
    reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    resize();
    handlers.resize = resize;
    window.addEventListener('resize', resize);
    if (reduce) return;
    handlers.move = function (e) {
      var r = host.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      if (Math.hypot(x - lastX, y - lastY) > 46) { lastX = x; lastY = y; spawn(x, y, false); }
    };
    handlers.down = function (e) {
      var r = host.getBoundingClientRect();
      for (var i = 0; i < 4; i++) spawn(e.clientX - r.left + (Math.random() - 0.5) * 70, e.clientY - r.top + (Math.random() - 0.5) * 70, true);
    };
    host.addEventListener('pointermove', handlers.move);
    host.addEventListener('pointerdown', handlers.down);
    for (var i = 0; i < 4; i++) spawn(w * (0.55 + Math.random() * 0.4), h * (0.15 + Math.random() * 0.7), true);
    io = new IntersectionObserver(function (en) {
      if (en[0].isIntersecting && !document.hidden) run(); else halt();
    });
    io.observe(host);
    handlers.vis = function () { if (document.hidden) halt(); };
    document.addEventListener('visibilitychange', handlers.vis);
  }

  function run() { if (running) return; running = true; last = performance.now(); raf = requestAnimationFrame(frame); }
  function halt() { running = false; cancelAnimationFrame(raf); }

  function stop() {
    halt();
    if (io) { io.disconnect(); io = null; }
    window.removeEventListener('resize', handlers.resize);
    document.removeEventListener('visibilitychange', handlers.vis);
    if (host && handlers.move) { host.removeEventListener('pointermove', handlers.move); host.removeEventListener('pointerdown', handlers.down); }
    handlers = {}; blots = []; host = null;
  }

  window.Ink = { start: start, stop: stop };
})();
